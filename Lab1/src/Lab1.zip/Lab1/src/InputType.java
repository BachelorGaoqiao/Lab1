/**
 * Created by zxx_1 on 2016/9/18.
 */
public enum InputType {
    Expression, Simplification, Derivation, Unrecognised, End
}
