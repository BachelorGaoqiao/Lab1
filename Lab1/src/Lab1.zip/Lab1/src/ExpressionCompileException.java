/**
 * Created by zxx_1 on 2016/9/18.
 */
public class ExpressionCompileException extends Exception{
    public ExpressionCompileException() {}
    public ExpressionCompileException(String msg) {
        super(msg);
    }
}
