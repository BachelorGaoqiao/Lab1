/**
 * Created by zxx_1 on 2016/9/18.
 */
public class Main {
    public static void main(String[] args) {
        InputScanner inputScanner = new InputScanner();
    }
}
